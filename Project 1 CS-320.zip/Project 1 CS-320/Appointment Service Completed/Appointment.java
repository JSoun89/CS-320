package milestone5;

import java.util.Date;
public class Appointment {
	private final String appointmentId;
	private Date appointmentDate;
	private String appointmentDescription;
	
	public Appointment(String appointmentId, Date appointmentDate, String appointmentDescription) {
		if(appointmentId == null || appointmentId.isEmpty()) {
			this.appointmentId = "NULL";
		}else if(appointmentId.length()>50) {
			this.appointmentId = appointmentId.substring(0,50);
		}else {
			this.appointmentId = appointmentId;
		}

		if(appointmentDate == null) {
			this.appointmentDate = new Date();
		}else if(appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid, please enter another date.");
		}
		else {
			this.appointmentDate = appointmentDate;
		}
		if(appointmentDescription == null || appointmentDescription.isEmpty()) {
			this.appointmentDescription = "NULL";
		}else if(appointmentDescription.length()>50) {
			this.appointmentDescription = appointmentDescription.substring(0,50);
		}else {
			this.appointmentDescription = appointmentDescription;
		}
	}
	public String getAppointmentId() {
		return appointmentId;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public String getAppointmentDescription() {
		return appointmentDescription;
	}

	public void setAppointmentDate(Date appointmentDate) {
		if(appointmentDate == null) {
			appointmentDate = new Date();
		}else if(appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Invalid, please enter new date.");
		}else {
			this.appointmentDate = appointmentDate;
		}
	}
	public void setAppointmentDescription(String appointmentDescription) {
		if(appointmentDescription == null || appointmentDescription.isEmpty()) {
			this.appointmentDescription = "NULL";
		}
		else if(appointmentDescription.length()>50) {
			this.appointmentDescription = appointmentDescription.substring(0,50);
		}else {
			this.appointmentDescription = appointmentDescription;
		}
	}
}
