package milestone5;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class AppointmentService {
	final private List<Appointment>appointmentList = new ArrayList<>();
	
	private String newUniqueId() {
		return UUID.randomUUID().toString().substring(0,Math.min(toString().length(), 10));
	}
	public void newAppointment() {
		Appointment appointment = new Appointment(newUniqueId(), new Date(),"");
		appointmentList.add(appointment);
	}
	public void newAppointment(Date date) {
		Appointment appointment = new Appointment(newUniqueId(),date,"");
		appointmentList.add(appointment);
	}
	public void newAppointment(Date date, String description) {
		Appointment appointment = new Appointment(newUniqueId(),date, description);
		appointmentList.add(appointment);
	}
	public void deleteAppointment(String id)throws Exception{
		appointmentList.remove(searchForAppointment(id));
	}
	protected List<Appointment>getAppointment(){return appointmentList;}
	private Appointment searchForAppointment(String id)throws Exception{
		int index = 0;
		while(index<appointmentList.size()) {
			if(id.equals(appointmentList.get(index).getAppointmentId())) {
				return appointmentList.get(index);
			}
			index++;
		}
		throw new Exception("Invalid, please try again!");
	}
}
