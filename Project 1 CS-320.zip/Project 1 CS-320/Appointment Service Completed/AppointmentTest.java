package milestone5;

import java.util.Date;

public class AppointmentTest {
	private Date Date() {
		return null;
	}
	void testAppointmentIdMoreThanTen() {
		Appointment appointment = new Appointment("ID", Date(),"");
		if(appointment.getAppointmentId().length()>10) {
			assert("Invalid, appointmentID greater than 10 characters.")!= null;

		}
	}
	void testAppointmentDescriptionMoreThanFifty() {
		Appointment appointment = new Appointment("ID", Date(), "");
		if(appointment.getAppointmentDescription().length()>50) {
			assert("Invalid, appointmentDescription greater than 50 characters.")!= null;
			
		}
	}
	void testAppointmentDateBeforeCurrent() {
		Appointment appointment = new Appointment("ID",Date(), "");
		if(appointment.getAppointmentDate().before(new Date()));
			assert("Invalid, enter another date")!=null;
		
		
	}
}


