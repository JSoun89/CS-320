package milestone3; //Adding package in order for all files to run under the right package.
import java.util.ArrayList;

public class ContactService {
    //List of contacts

    private ArrayList<Contact> contacts;

    public ContactService() {
        contacts = new ArrayList<>();
    }

    //Add contact
    public boolean addContact(Contact contact) {
        boolean contactAlready = false;
        //run through all the contacts in the list made
        for (Contact contactList : contacts) {
            if (contactList.equals(contact)) {
                contactAlready = true;
            }
        }
        //if not a contact add it
        if (!contactAlready) {
            contacts.add(contact);
            return true;
        } else {
            return false;
        }
    }

    //Delete contact
    public boolean deleteContact(String string) {
        for (Contact contactList : contacts) {
            if (contactList.getContactID().equals(string)) {
                contacts.remove(contactList);
                return true;
            }
        }
      
        return false;
    }

    //Update contact
    public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber,
            String address) {
        for (Contact contactList : contacts) {
            if (contactList.getContactID().equals(contactID)) {
                if (!firstName.equals("") && !(firstName.length() > 10)) {
                    contactList.setFirstName(firstName);
                }
                if (!lastName.equals("") && !(lastName.length() > 10)) {
                    contactList.setFirstName(lastName);
                }
                if (!phoneNumber.equals("") && (phoneNumber.length() == 10)) {
                    contactList.setFirstName(phoneNumber);
                }
                if (!address.equals("") && !(address.length() > 30)) {
                    contactList.setFirstName(address);
                }
                return true;
            }
        }
        
        return false;
    }
}