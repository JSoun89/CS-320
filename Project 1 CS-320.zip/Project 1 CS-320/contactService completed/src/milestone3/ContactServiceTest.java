package milestone3;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {


		 //test add
		    public void testAdd() {
		        ContactService cs = new ContactService();
		        String NULL = null;
		        Contact test1 = new Contact("7583928", "Janet", "Poe", "1111111111", NULL);
		        assertEquals(true, cs.addContact(test1));
		       
		    }

		   //test delete
		    public void testDelete() {
		        ContactService cs = new ContactService();
		        
		        String NULL = null;
		        Contact test1 = new Contact("7583928", "Janet", "Poe", "1111111111", NULL);
		        Contact test2 = new Contact("5439038", "Val", "Torres", "5839587375", NULL);
		        Contact test3 = new Contact("8593854", "Vic", "Smith", "5839548593", NULL);

		        cs.addContact(test1);
		        cs.addContact(test2);
		        cs.addContact(test3);

		        assertEquals(true, cs.deleteContact("5439038"));
		        assertEquals(false, cs.deleteContact("5439039"));
		        assertEquals(false, cs.deleteContact("5439040"));
		    }

		   //test update	
		    public void testUpdate() {
		        ContactService cs = new ContactService();
		        
		        String NULL = null;
		        Contact test1 = new Contact("7583928", "Janet", "Poe", "1111111111", NULL);
		        Contact test2 = new Contact("5439038", "Val", "Torres", "5839587375", NULL);
		        Contact test3 = new Contact("8593854", "Vic", "Smith", "5839548593", NULL);
		        

		        cs.addContact(test1);
		        cs.addContact(test2);
		        cs.addContact(test3);

		        assertEquals(true, cs.updateContact("8593854", "VicFirst", "SmithLast", "5839548593", "Land of Java"));
		        assertEquals(false, cs.updateContact("8593855", "VicFirst", "SmithLast", "5839548593", "Land of Java"));
		    }
	}
