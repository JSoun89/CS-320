package milestone4;

public class TaskTest {
	private void fail(String string){}
//Task ID needs to be less than 10 characters long
void testTaskIdMoreThanTen(){
	Task task = new Task("Name","Description",null);
	if(task.getTaskId().length()>10){
		fail("Invalid, taskId needs to be less than 10.");
	}
}
//Task name needs to be less than 20 characters long
void testTaskNameMoreThanTwenty(){
	Task task = new Task("Name","Description",null);
	if(task.getName().length()>20){
		fail("Invalid, task name needs to be less than 20.");
	}
}
//Task description needs to be less than 50 characters long
void testTaskDescriptionMoreThanFifty(){
	Task task = new Task("Name","Description",null);
	if(task.getDescription().length()>50){
		fail("Invalid, task description needs to be less than 50.");
		}
	}
}
