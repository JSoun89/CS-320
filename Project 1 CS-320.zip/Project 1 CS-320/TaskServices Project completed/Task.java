package milestone4;

public class Task {
	private String taskId;
	private String name;
	private String description;
	
	Task(){
		taskId = "Initial";
		name = "Initial";
		description = "Initial Description";
		}
	Task(String taskId, String name, String description){
		setTaskId(taskId);
		setName(name, taskId);
		setDescription(description);
		}
	public final String getTaskId(){
		return taskId;
		}
	public final String getName() {
		return name;
		}
	public final String getDescription() {
		return description;
		}
	private void setTaskId(String taskId) {
		if(taskId.length() > 10) {
			throw new IllegalArgumentException("Invalid, taskId needs to be shorter than 10 characters.");
			}else {
				this.taskId = taskId;
				}
	}
	protected void setName(String name, String taskId) {
		if(name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid, task name needs to be shorter than 20 characters.");
			}else {
				this.name = name;
				}
	}
	protected void setDescription(String description) {
		if(description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid, task description needs to be shorter than 50 characters.");
			}else {
				this.description= description;
				}
	}
}